import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;
import java.util.Random;
import java.util.Calendar;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import javax.swing.*;

public class Login implements ActionListener{

	private static JFrame frame = new JFrame();
    private static JLabel welcome = new JLabel(), randomPass = new JLabel();
//    private static ImageIcon img = new ImageIcon("backgroundImg.jpg");
//    private static JLabel background = new JLabel("",img,JLabel.CENTER);
    
    private static JButton passwordGen = new JButton("Generate Password");
    private static JLabel warning = new JLabel();
    private static String warningMsg = "Please write this password down, and do not show anybody else "
    		+ "as you will not be able to generate the same password again.";
    
    private static Date date = Calendar.getInstance().getTime();
    private static DateFormat dateFormat = new SimpleDateFormat("yyyyMMddhhmmss");
    
    private static String caps = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    private static String lower = "abcdefghijklmnopqrstuv";
    private static String nums = "0123456789";
    private static String misc = "!@#$%^&()-=_+[]{}<>,.?*";
    private static String[] arr = {caps, lower, nums, misc};
    
    private static Random random = new Random();
    private static String pass = "";

    public Login(String user){
    
        welcome.setBounds(0,0,600,50);
        welcome.setFont(new Font(null,Font.PLAIN,25));
        welcome.setText("You are now in the Secure Password Generator.");
        welcome.setForeground(Color.BLACK);
        
        JLabel welcomeName = new JLabel("Welcome, " + user);
        welcomeName.setFont(new Font(null,Font.PLAIN,25));
        welcomeName.setBounds(0,50,600,50);
        welcomeName.setForeground(Color.BLACK);
        	
        frame.add(welcome);
        frame.add(welcomeName);
        
        randomPass.setBounds(0,150,600,50);
        randomPass.setFont(new Font(null,Font.PLAIN,18));
        frame.add(randomPass);
        
        passwordGen.setBounds(0,100,200,25);
        passwordGen.addActionListener(this);
        frame.add(passwordGen);
        
        warning.setBounds(0,200,600,200);
        warning.setFont(new Font("",Font.PLAIN,20));
        warning.setForeground(Color.RED);
        frame.add(warning);
        
//        background.setBounds(0,0,700,650);
//        frame.add(background);
        
        
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(700,650);
        frame.setLayout(null);
        
        frame.setVisible(true);

    }
    
    @Override
    public void actionPerformed(ActionEvent e){
    	if(e.getSource() == passwordGen) {
    		createPassword();
    		randomPass.setText("Secure password: " + pass);
    		randomPass.setForeground(Color.BLACK);
    		passwordGen.setEnabled(false);
    		warning.setText("<html><p>" + warningMsg + "</p></html>");
    		warning.setForeground(Color.RED);
    	}
    }
    
    public void createPassword() {
    	for(int i = 0; i < 6; i++) {
    		int index = random.nextInt(arr.length);
    		pass += arr[index].charAt(random.nextInt(arr[index].length()));
    		pass += dateFormat.format(date).charAt(random.nextInt(dateFormat.format(date).length()));
    		if(index == 2) {
    			pass += arr[3].charAt(random.nextInt(arr[index].length()));
    		}else {
    			pass += arr[index].charAt(random.nextInt(arr[index].length()));
    		}
    	}
    }
    
}
